/*
 * client.c - Client window management implementation for NexWM
 *
 * Managed clients are reparented into a WM-owned decoration frame:
 *
 *   ┌──────────────────────────────── frame (c->x, c->y, c->width, c->height)
 *   │  ┌──────────────────────── titlebar (NEX_TITLEBAR_H, painted)
 *   │  │  Title text        [—] [□] [X]
 *   │  ├─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─
 *   │  │  ┌───────────────── client window (reparented, holds app content)
 *   │  │  │
 *   │  │  │
 *
 * All geometry stored in nex_client_t (x/y/width/height) is FRAME
 * geometry; the client is placed inside the frame by
 * nex_client_place_client(), which leaves a border of
 * g_config.border_width on the left/right/bottom and the titlebar on top.
 */

#include "client.h"
#include "wm.h"
#include "atoms.h"
#include "ewmh.h"
#include "monitor.h"
#include "config.h"
#include "log.h"
#include <string.h>
#include <stdlib.h>
#include <limits.h>

nex_client_t *g_clients = NULL;
nex_client_t *g_focused = NULL;

extern xcb_connection_t *g_conn;
extern xcb_screen_t *g_screen;
extern nex_atoms_t g_atoms;
extern nex_config_t g_config;

/* ICCCM WM_STATE values (set on the client window as WM_STATE property). */
enum {
    NEX_WM_STATE_WITHDRAWN = 0,
    NEX_WM_STATE_NORMAL = 1,
    NEX_WM_STATE_ICONIC = 3
};

/* Flag-bits of the X WM_NORMAL_HINTS property. */
enum {
    NEX_HINT_POSITION      = 4,    /* PPosition  */
    NEX_HINT_SIZE          = 8,    /* PSize      */
    NEX_HINT_MIN_SIZE      = 16,   /* PMinSize   */
    NEX_HINT_MAX_SIZE      = 32,   /* PMaxSize   */
    NEX_HINT_RESIZE_INC    = 64,   /* PResizeInc */
    NEX_HINT_ASPECT        = 128,  /* PAspect    */
    NEX_HINT_BASE_SIZE     = 256,  /* PBaseSize  */
    NEX_HINT_WIN_GRAVITY   = 512   /* PWinGravity*/
};

/* ── small drawing helpers (local, style matches NexPanel) ──────────────── */

static xcb_gc_t make_gc(int fg, int bg)
{
    xcb_gc_t gc = xcb_generate_id(g_conn);
    uint32_t mask = XCB_GC_FOREGROUND | XCB_GC_BACKGROUND | XCB_GC_GRAPHICS_EXPOSURES;
    uint32_t vals[3] = { (uint32_t)fg, (uint32_t)bg, 0 };
    xcb_create_gc(g_conn, gc, g_root, mask, vals);
    return gc;
}

static void fill_rect(xcb_drawable_t d, xcb_gc_t gc, int x, int y, int w, int h)
{
    xcb_rectangle_t r = { (int16_t)x, (int16_t)y,
                          (uint16_t)(w > 0 ? w : 0),
                          (uint16_t)(h > 0 ? h : 0) };
    xcb_poly_fill_rectangle(g_conn, d, gc, 1, &r);
}

static void draw_text8(xcb_drawable_t d, xcb_gc_t gc, int x, int y, const char *text)
{
    if (!text || !*text) return;
    xcb_image_text_8(g_conn, (uint8_t)strlen(text), d, gc,
                     (int16_t)x, (int16_t)y, text);
}

/* ── lookup helpers ─────────────────────────────────────────────────────── */

nex_client_t *nex_client_find_frame(xcb_window_t frame)
{
    nex_client_t *c;
    for (c = g_clients; c; c = c->next) {
        if (c->frame == frame) return c;
    }
    return NULL;
}

/* ── size hints (WM_NORMAL_HINTS / WM_SIZE_HINTS) ──────────────────────── */

void nex_client_read_size_hints(nex_client_t *c)
{
    if (!c) return;
    c->minw = 1;
    c->minh = 1;
    c->maxw = INT_MAX;
    c->maxh = INT_MAX;
    c->basew = 0;
    c->baseh = 0;
    c->incw = 1;
    c->inch = 1;

    /* WM_SIZE_HINTS is a packed array of 18 int32 values (ICCCM §4.1.2.3).
     * Field offsets: 0=flags 1=x 2=y 3=w 4=h 5=min_w 6=min_h 7=max_w
     * 8=max_h 9=w_inc 10=h_inc 11=min_aspect_x 12=min_aspect_y
     * 13=max_aspect_x 14=max_aspect_y 15=base_w 16=base_h 17=win_gravity. */
    xcb_get_property_cookie_t pc = xcb_get_property(
        g_conn, 0, c->window, g_atoms.wm_normal_hints,
        XCB_ATOM_WM_SIZE_HINTS, 0, 18);
    xcb_get_property_reply_t *rep = xcb_get_property_reply(g_conn, pc, NULL);
    if (!rep || rep->type == XCB_ATOM_NONE) {
        free(rep);
        return;
    }

    int len = xcb_get_property_value_length(rep);
    if (len < 9 * (int)sizeof(int32_t)) {
        free(rep);
        return;
    }
    const int32_t *d = (const int32_t *)xcb_get_property_value(rep);
    int n = len / (int)sizeof(int32_t);
    if (n > 18) n = 18;
    uint32_t flags = (uint32_t)d[0];

    if ((flags & NEX_HINT_MIN_SIZE) && n > 6) {
        c->minw = (int)d[5];
        c->minh = (int)d[6];
    }
    if ((flags & NEX_HINT_MAX_SIZE) && n > 8) {
        c->maxw = (int)d[7];
        c->maxh = (int)d[8];
    }
    if ((flags & NEX_HINT_RESIZE_INC) && n > 10) {
        c->incw = (int)d[9];
        c->inch = (int)d[10];
    }
    if ((flags & NEX_HINT_BASE_SIZE) && n > 16) {
        c->basew = (int)d[15];
        c->baseh = (int)d[16];
    }

    /* Sanitize: increments >= 1, maximums >= minimums. */
    if (c->incw < 1) c->incw = 1;
    if (c->inch < 1) c->inch = 1;
    if (c->minw < 1) c->minw = 1;
    if (c->minh < 1) c->minh = 1;
    if (c->maxw > 0 && c->maxw < c->minw) c->maxw = c->minw;
    if (c->maxh > 0 && c->maxh < c->minh) c->maxh = c->minh;

    free(rep);
    NEX_DEBUG("Size hints for 0x%x: min %dx%d max %dx%d inc %dx%d base %dx%d",
              c->window, c->minw, c->minh,
              c->maxw == INT_MAX ? -1 : c->maxw,
              c->maxh == INT_MAX ? -1 : c->maxh,
              c->incw, c->inch, c->basew, c->baseh);
}

/* Apply WM_NORMAL_HINTS to a desired FRAME size. *w / *h are in frame
 * coordinates; hints are expressed in client coordinates, so the titlebar
 * strip and the border are subtracted before clamping. */
void nex_client_apply_size_hints(nex_client_t *c, int *w, int *h)
{
    if (!c || !w || !h) return;
    int bw = (int)g_config.border_width;
    int cw = *w - 2 * bw;               /* client width  */
    int ch = *h - NEX_TITLEBAR_H - bw;  /* client height */

    if (cw < 1) cw = 1;
    if (ch < 1) ch = 1;

    if (cw < c->minw) cw = c->minw;
    if (ch < c->minh) ch = c->minh;
    if (c->maxw > 0 && cw > c->maxw) cw = c->maxw;
    if (c->maxh > 0 && ch > c->maxh) ch = c->maxh;

    /* Honor resize increments (round up, then fall back below the maximum). */
    if (c->incw > 1) {
        int rw = cw - c->basew;
        if (rw < 0) rw = 0;
        int stepped = c->basew + ((rw + c->incw - 1) / c->incw) * c->incw;
        if (c->maxw > 0 && stepped > c->maxw) {
            int cur = stepped - c->incw;
            stepped = (cur >= c->minw) ? cur : c->minw;
        }
        cw = stepped;
    }
    if (c->inch > 1) {
        int rh = ch - c->baseh;
        if (rh < 0) rh = 0;
        int stepped = c->baseh + ((rh + c->inch - 1) / c->inch) * c->inch;
        if (c->maxh > 0 && stepped > c->maxh) {
            int cur = stepped - c->inch;
            stepped = (cur >= c->minh) ? cur : c->minh;
        }
        ch = stepped;
    }

    *w = cw + 2 * bw;
    *h = ch + NEX_TITLEBAR_H + bw;
}
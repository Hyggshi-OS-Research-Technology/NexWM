components/wallpaper/nex-wallpaper.o: \
 components/wallpaper/nex-wallpaper.c \
 components/wallpaper/nex-wallpaper.h
components/wallpaper/nex-wallpaper.h:

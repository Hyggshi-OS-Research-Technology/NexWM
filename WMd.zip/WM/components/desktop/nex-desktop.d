components/desktop/nex-desktop.o: components/desktop/nex-desktop.c \
 components/desktop/nex-desktop.h
components/desktop/nex-desktop.h:

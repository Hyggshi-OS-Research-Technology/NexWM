components/panel/nex-panel.o: components/panel/nex-panel.c \
 components/panel/nex-panel.h
components/panel/nex-panel.h:

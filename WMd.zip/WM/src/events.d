src/events.o: src/events.c src/events.h src/wm.h \
 include/xcb/xcb_keysyms.h src/atoms.h src/config.h src/client.h \
 include/xcb/xcb_icccm.h src/workspace.h src/focus.h src/keybind.h \
 src/ewmh.h include/xcb/xcb_ewmh.h src/rules.h src/monitor.h src/log.h
src/events.h:
src/wm.h:
include/xcb/xcb_keysyms.h:
src/atoms.h:
src/config.h:
src/client.h:
include/xcb/xcb_icccm.h:
src/workspace.h:
src/focus.h:
src/keybind.h:
src/ewmh.h:
include/xcb/xcb_ewmh.h:
src/rules.h:
src/monitor.h:
src/log.h:

src/nexwmctl.o: src/nexwmctl.c

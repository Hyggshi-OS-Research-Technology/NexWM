src/rules.o: src/rules.c src/rules.h src/client.h include/xcb/xcb_icccm.h \
 src/config.h src/log.h
src/rules.h:
src/client.h:
include/xcb/xcb_icccm.h:
src/config.h:
src/log.h:

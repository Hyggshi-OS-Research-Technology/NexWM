src/ipc.o: src/ipc.c src/ipc.h src/client.h include/xcb/xcb_icccm.h \
 src/workspace.h src/config.h src/ewmh.h include/xcb/xcb_ewmh.h src/log.h \
 src/wm.h include/xcb/xcb_keysyms.h src/atoms.h
src/ipc.h:
src/client.h:
include/xcb/xcb_icccm.h:
src/workspace.h:
src/config.h:
src/ewmh.h:
include/xcb/xcb_ewmh.h:
src/log.h:
src/wm.h:
include/xcb/xcb_keysyms.h:
src/atoms.h:

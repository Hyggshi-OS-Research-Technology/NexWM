src/client.o: src/client.c src/client.h include/xcb/xcb_icccm.h src/wm.h \
 include/xcb/xcb_keysyms.h src/atoms.h src/config.h src/ewmh.h \
 include/xcb/xcb_ewmh.h src/monitor.h src/log.h
src/client.h:
include/xcb/xcb_icccm.h:
src/wm.h:
include/xcb/xcb_keysyms.h:
src/atoms.h:
src/config.h:
src/ewmh.h:
include/xcb/xcb_ewmh.h:
src/monitor.h:
src/log.h:

src/main.o: src/main.c src/wm.h include/xcb/xcb_keysyms.h src/atoms.h \
 src/config.h src/log.h
src/wm.h:
include/xcb/xcb_keysyms.h:
src/atoms.h:
src/config.h:
src/log.h:

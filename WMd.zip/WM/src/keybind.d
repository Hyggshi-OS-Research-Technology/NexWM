src/keybind.o: src/keybind.c src/keybind.h include/xcb/xcb_keysyms.h \
 src/config.h src/client.h include/xcb/xcb_icccm.h src/workspace.h \
 src/focus.h src/monitor.h src/wm.h src/atoms.h src/log.h
src/keybind.h:
include/xcb/xcb_keysyms.h:
src/config.h:
src/client.h:
include/xcb/xcb_icccm.h:
src/workspace.h:
src/focus.h:
src/monitor.h:
src/wm.h:
src/atoms.h:
src/log.h:

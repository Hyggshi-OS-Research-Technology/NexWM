src/workspace.o: src/workspace.c src/workspace.h src/client.h \
 include/xcb/xcb_icccm.h src/config.h src/log.h src/layout.h \
 src/monitor.h
src/workspace.h:
src/client.h:
include/xcb/xcb_icccm.h:
src/config.h:
src/log.h:
src/layout.h:
src/monitor.h:

src/monitor.o: src/monitor.c src/monitor.h src/config.h src/log.h
src/monitor.h:
src/config.h:
src/log.h:

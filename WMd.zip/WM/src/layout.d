src/layout.o: src/layout.c src/layout.h src/client.h \
 include/xcb/xcb_icccm.h src/monitor.h src/config.h src/log.h
src/layout.h:
src/client.h:
include/xcb/xcb_icccm.h:
src/monitor.h:
src/config.h:
src/log.h:

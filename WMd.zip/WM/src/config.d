src/config.o: src/config.c src/config.h src/log.h
src/config.h:
src/log.h:

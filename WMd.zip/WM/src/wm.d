src/wm.o: src/wm.c src/wm.h include/xcb/xcb_keysyms.h src/atoms.h \
 src/config.h src/events.h src/client.h include/xcb/xcb_icccm.h \
 src/workspace.h src/monitor.h src/keybind.h src/ewmh.h \
 include/xcb/xcb_ewmh.h src/rules.h src/ipc.h src/log.h
src/wm.h:
include/xcb/xcb_keysyms.h:
src/atoms.h:
src/config.h:
src/events.h:
src/client.h:
include/xcb/xcb_icccm.h:
src/workspace.h:
src/monitor.h:
src/keybind.h:
src/ewmh.h:
include/xcb/xcb_ewmh.h:
src/rules.h:
src/ipc.h:
src/log.h:

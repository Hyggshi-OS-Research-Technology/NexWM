src/atoms.o: src/atoms.c src/atoms.h src/log.h
src/atoms.h:
src/log.h:

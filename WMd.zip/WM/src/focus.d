src/focus.o: src/focus.c src/focus.h src/client.h include/xcb/xcb_icccm.h \
 src/workspace.h src/config.h src/log.h
src/focus.h:
src/client.h:
include/xcb/xcb_icccm.h:
src/workspace.h:
src/config.h:
src/log.h:

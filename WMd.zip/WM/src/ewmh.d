src/ewmh.o: src/ewmh.c src/ewmh.h include/xcb/xcb_ewmh.h src/atoms.h \
 src/client.h include/xcb/xcb_icccm.h src/workspace.h src/config.h \
 src/log.h
src/ewmh.h:
include/xcb/xcb_ewmh.h:
src/atoms.h:
src/client.h:
include/xcb/xcb_icccm.h:
src/workspace.h:
src/config.h:
src/log.h:
